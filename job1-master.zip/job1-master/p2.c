#include <stdio.h>

int strdex(char s[],char t);

int main()
{
	char a[]="manzanita", b = getchar();
	printf("%d",strdex(a,b));
}

int strdex(char s[],char t)
{
	int i , j = 0;
	for(i=0;s[i]!='\0';i++)
		if (s[i] == t)
			j=i;
	if(j==0)
		return -1;
	return j;
}

