#include <stdio.h>
#include <ctype.h>

float potencia(float n,int p)
{
	int i,m,b=0;
	float a;

	m=n;
	if (p == 0)
		return 1;
	if (p < 0){
		b=1;
		p*=-1;
	}
	for(i=1;i<p;i++)
		n*=m;
	if (b==1){
		a = 1/n;
		return a;
	}
	return n;
}

double notacion(char s[])
{
	double valor,decim,parcial,poten;
	int i=0,signo,e,sig,x;

	signo = (s[i]=='-') ? -1 : 1 ;
	if (s[i] == '+' || s[i] == '-')
		i++;
	for (valor = 0.0 ; isdigit(s[i]) ; i++)
		valor = 10.0 * valor + (s[i] - '0');
	if (s[i]=='.')
		i++;
	for (decim = 1.0 ; isdigit(s[i]) ; i++){
		valor = 10.0 * valor + (s[i] - '0');
		decim *= 10.0;
	}

	parcial = signo * valor/decim ;

	if (s[i]=='e')
		i++;
	sig = (s[i]=='-') ? -1 : 1;
	if (s[i]=='+' || s[i] == '-')
		i++;
	for (e = 0 ; isdigit(s[i]) ; i++)
		e = 10 * e + (s[i] - '0');
	x = sig * e;
	poten = potencia(10,x);
	return parcial * poten;
}

double main()
{
	char a[]="123.45e-6";
	printf("%f", notacion(a));
}


