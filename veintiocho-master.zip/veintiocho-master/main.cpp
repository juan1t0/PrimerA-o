#include <iostream>
#include <string>

using namespace std;


const string vocales ="aeiou";
string pyL(const string word)
{
    if(word.size() == O)
        return word;

    if((vocales.find(word[0])!= -1)||(word.find(word[0]^32)!= -1)
        return word + "-way";

    else if (word.find("qu")==0 || word.find(word.find("QU")==0)
        return word.substr(2,word.size()-2)+"-"+ word.substr(o,2) + "ay";

    return word.substr(1,word,size()-1)+"-"+word[0]+"ay";
}
int main()
{
    string word = "QUERI";
    cout<<"la nueva cadena es "<< pyL(word)<<endl;

}
