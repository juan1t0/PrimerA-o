#include "point.h"
#include <iostream>
#include <new>
using namespace std;

double Point::getX(){
    return x;
}

double Point::getY(){
    return y;
}
void Point::setX(double a){
    x = a;
}
void Point::setY(double b){
    y = b;
}
void Point::mod(double newx,double newy){
    x=newx;
    y=newy;
}
void Point::print(){
    cout<< "("<<x<<","<<y<<")"<<endl;
}

void Vector::printv(){
    inicio.print();
    cout<<"->";
    finale.print();
    cout<<endl;
}

// ----------------------------------------------------------

Pointarray::Pointarray(const Point points[],const int sizz)
{
    tamanio=sizz;
    arrray=new Point[sizz];
    int i;
    for(i=0;i<=sizz;i++){
        arrray[i]=points[i];
//        elem +=1;
    }
    cout<<"se creo arreglo"<<endl;
}
Pointarray::Pointarray(const Pointarray& p)
{
    tamanio = p.tamanio;
    arrray=p.arrray;
//    elem=p.elem;
    cout<<"se creo arreglo"<<endl;
}

void Pointarray::finit(const Point& p){
    int i;
    for(i=0;i<tamanio;i++)
        ;
//    arrray[i] = new Point(p);
//    arrray[i]=p;
}
void Pointarray::insertar(const int position,const Point &p){
    int i;
    for(i=0;i<position;i++)
        ;
//    arrray[i]=new Point(p);
//    arrray[i]=p;
}
void Pointarray::remover(const int position){
    int i;
    for(i=0;i<=position;i++)
        ;
//    delete &arrray[i];
}
const int Pointarray::tam(){
    return sizeof(arrray);
}
void Pointarray::borrar(){
    delete arrray;
    tamanio=0;
}
void Pointarray::imprimir(){
    int i;
    for(i=0;i<=tamanio;i++)
        arrray[i].print();
}
