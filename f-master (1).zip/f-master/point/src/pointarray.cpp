#include "pointarray.h"
/*
pointarray::pointarray()
{
    //ctor
}

pointarray::~pointarray()
{
    //dtor
}
*/
