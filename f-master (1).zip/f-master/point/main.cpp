#include <iostream>
#include "point.h"
using namespace std;


int main()
{
    Point punto(1.0,3.5);
    Point punto2(3.2,5.3);
    Point punto3(punto2);
    Vector vec(punto,punto2);
    punto3.print();
    vec.printv();

    Point puntos[5];
    Pointarray puntitos(puntos,4);
    Pointarray puntos3(puntitos);
    int a =puntos3.tam();
 //   puntitos.finit(punto2);
//    puntitos.insertar(1,punto);
//    puntitos.imprimir();
 //   puntitos.remover(1);*/
//    puntitos.imprimir();
    cout<<a<<endl;
    return 0;

}
