#ifndef POINTARRAY_H
#define POINTARRAY_H


class Pointarray
{
    public:
    int tamanio;
    Point *arrai;
};

#endif // POINTARRAY_H
