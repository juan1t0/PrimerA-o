#ifndef POINT_H
#define POINT_H


class Point
{
    private: double x,y;

    public:
        Point(){x=0.0;y=0.0;}
        Point(double xx,double yy){x=xx;y=yy;}
        Point(Point &o){x=o.x;y=o.y;}

        double getX();
        double getY();
        void setX(double a);
        void setY(double b);
        void mod(double newx,double newy);
        void print();
};
class Vector
{
    private:Point inicio;Point finale;
    public:
        Vector(){
        inicio.setX(0.0);inicio.setY(0.0);
        finale.setX(0.0);finale.setY(0.0);}

        Vector(Point a,Point b){
        inicio.setX(a.getX());inicio.setY(a.getY());
        finale.setX(b.getX());finale.setY(b.getY());}

        Vector(Vector &o){
        inicio=o.inicio;
        finale=o.finale;
        }

        void printv();

};
class Pointarray
{
    public:
        int tamanio;
       // int elem;
        Point *arrray;

        Pointarray(const Point points[],const int sizz);

        Pointarray(const Pointarray& p);

        void insertar(const int position,const Point &p);
        void finit(const Point &p);
        void remover(const int position);
        const int tam();
        void borrar();
        void imprimir();
};
#endif
