#include <stdio.h>
int main ()
{
    char a;
    a = getchar() ^ 32;
    printf("%c",a);
    return 0;
}

