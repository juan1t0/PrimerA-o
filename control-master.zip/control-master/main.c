#include <stdio.h>
#include <stdlib.h>

int invertir(char t[],int i,int j)
{
    char a;
    if (i >=j)
        return t;
    else
        a = t[i];
        t[i]=t[j-1];
        t[j-1]=a;
        return invertir(t,++i,--j);

}

main()
{
   char s[]="manzanita";
   int a=0,b=9;
   invertir(s,a,b);
   printf("%s",s);
}
