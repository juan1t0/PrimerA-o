#include <iostream>
#include "point.h"
#include "vector.h"
#include "pointarray.h"
#include "Poligono.h"
#include "Vectorarray.h"


using namespace std;

int main()
{
    Point punto;
    Point punt(3.2,4.5);
    punto.print();
    Vector vec(punto,punt);
    vec.imprimir();

    Point a[3];
/*
    Pointarray b(a,2);
    Pointarray c(b);
    c.finit(punt);
    c.inserta(punt,2);
    c.remover(1);
    c.imprimelo();
    cout<<c.getSize()<<endl;
    Point *t = c.getpoint(1);
    t->print();
//--------------------------------------------------------------


    Vector vv[4];
    Vectorarray vec1;
    Vectorarray vec2(vv,3);
    Vectorarray vec3(vec2);

    vec2.finit(vec);
    vec2.remover(1);
    vec2.inserta(vec,0);
    vec2.imprimelo();
    Vector* d=vec2.getvector(0);
    d->imprimir();
    vec2.clean();
*/
//-------------------------------------------------------------
    Pointarray w(a,2);
    Poligono tri(w);
    Poligono tro(tri);
    Point q(1.0,1.0);Point z(4.0,3.0);
    Rectangulo rec(q,z);
    double ar = rec.area();
    cout<<"el area del rectangulo es : "<< ar << " u²"<<endl;

    Point q1(0.0,0.0);Point q2(0.0,3.0);Point q3(4.0,0.0);
    Triangulo tr(q1,q2,q3);
    double er = tr.area();
    cout<<"el area del triangulo es: "<< er<<" u²"<<endl;


}
