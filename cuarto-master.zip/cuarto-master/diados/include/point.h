#ifndef POINT_H
#define POINT_H


class Point
{
    private:
        double x;
        double y;
    public:
        Point();
        Point(double , double);
        Point(Point&p);

        void print();
        double getX();
        double getY();
        void setX(double);
        void setY(double);

        double distancia(Point);

        virtual ~Point();

};

#endif // POINT_H
