#ifndef POINTARRAY_H
#define POINTARRAY_H
#include "point.h"

class Pointarray
{
    private:
        int sizze;
        Point*aray;
        void resize(const int a);
    public:
        Pointarray();
        Pointarray(const Point[],const int );
        Pointarray(const Pointarray &p);

        void finit(const Point p);
        void inserta(const Point pp,const int a);
        void remover(const int position);
        int getSize();
        void clean();
        Point* getpoint(const int );
        void imprimelo();

};

#endif // POINTARRAY_H
