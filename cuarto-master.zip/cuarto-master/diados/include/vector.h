#ifndef VECTOR_H
#define VECTOR_H
#include "point.h"

class Vector
{
    private:
        Point star;
        Point endd;
    public:
        Vector();
        Vector(Point,Point);
        Vector(Vector &v);

        Point getS();
        Point getE();

        void setS(Point);
        void setE(Point);

        void imprimir();

        virtual ~Vector();
};

#endif // VECTOR_H
