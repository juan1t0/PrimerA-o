#ifndef VECTORARRAY_H
#define VECTORARRAY_H
#include "vector.h"

class Vectorarray
{
    private:
        int sizze;
        Vector*arrray;
        void resize(const int a);
    public:
        Vectorarray();
        Vectorarray(const Vector[],const int );
        Vectorarray(const Vectorarray &p);

        void finit(const Vector );
        void inserta(const Vector ,const int );
        void remover(const int);
        int getSize();
        void clean();
        Vector* getvector(const int );
        void imprimelo();

};
#endif // VECTORARRAY_H
