#ifndef POLIGONO_H
#define POLIGONO_H
#include "pointarray.h"
#include "point.h"



class Poligono
{
    protected:
        Pointarray vertices;
        static int ins;
    public:
        Poligono();
        Poligono(Point[],int );
        Poligono(const Pointarray);
        Poligono(Poligono &h);

        virtual double area(){};
        const int getnum();
        const int getsides();
        const Pointarray* getvertices();

        ~Poligono();
};

#endif // POLIGONO_H
class Rectangulo:public Poligono
{
    public:
        Rectangulo(Point,Point);
        Rectangulo(int , int , int , int);
        double area();
};
class Triangulo:public Poligono
{
    public:
        Triangulo(Point,Point,Point);

        double area();
};
