#include "vector.h"
#include <iostream>

using namespace std;
Vector::Vector(){
    star.setX(0.0);star.setY(0.0);
    endd.setX(0.0);endd.setY(0.0);
}
Vector::Vector(Point a,Point b){
    star.setX(a.getX());star.setY(a.getY());
    endd.setX(b.getX());endd.setY(b.getY());
}
Vector::Vector(Vector &v){
    star=v.getS();
    endd=v.getE();
}
Point Vector::getS(){
return star;
}
Point Vector::getE(){
return endd;
}
void Vector::setS(Point a){
    star = a;
}
void Vector::setE(Point b){
    endd = b;
}
void Vector::imprimir(){
    star.print();
    cout<<"->";
    endd.print();
    cout<<endl;


}
Vector::~Vector()
{
    //dtor
}
