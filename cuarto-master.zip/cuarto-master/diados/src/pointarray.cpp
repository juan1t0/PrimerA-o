#include "pointarray.h"
#include <iostream>

using namespace std;

Pointarray::Pointarray()
{
    sizze = 0;
    aray = new Point[0];
}
Pointarray::Pointarray(const Point points[],const int a){
    sizze=a;
    aray=new Point[a];
    for(int i=0;i<a;i++)
        aray[i]=points[i];
}
Pointarray::Pointarray(const Pointarray&p){
    sizze = p.sizze;
    aray = new Point[sizze];
    for(int i;i<sizze;i++)
        aray[i]=p.aray[i];

}
void Pointarray::resize(const int a){
    Point *x;
    x=new Point[a];
    this-> sizze=a;
    for(int i=0;i<a;i++)
        x[i]=aray[i];
    delete[] aray;
    aray = x;
}
void Pointarray::finit(const Point p){
    resize(sizze+1);
    aray[sizze-1]=p;
}
void Pointarray::inserta(const Point pp,const int a){
    resize(sizze + 1);
    for(int i = sizze; i > a;i--)
        aray[i]=aray[--i];
    aray[a]=pp;
}
void Pointarray::remover(const int position){
for(int i=position +1;i<=sizze;i++)
    aray[i-1]=aray[i];
resize(sizze-1);
}
int Pointarray::getSize(){
    return sizze;
}
void Pointarray::clean(){
    resize(0);
    delete[] aray;
}
Point* Pointarray::getpoint(const int position){
    for(int i=0;i<sizze;i++)
        if(i==position)
            return &aray[i];
    return NULL;
}
void Pointarray::imprimelo(){
    for(int i=0;i<sizze;i++)
        aray[i].print();
}
