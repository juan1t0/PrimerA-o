#include "Vectorarray.h"
#include "vector.h"
#include <iostream>
using namespace std;

Vectorarray::Vectorarray()
{
    sizze=0;
    arrray=new Vector[0];
    cout<<"se creo arreglo de vectores"<<endl;
}
Vectorarray::Vectorarray(const Vector v[],const int s){
    sizze=s;
    arrray=new Vector[s];
    for(int i=0;i<s;i++)
        arrray[i]=v[i];
    cout<<"se creo arreglo de vectores"<<endl;
}
Vectorarray::Vectorarray(const Vectorarray &vec){
    this->sizze=vec.sizze;
    this->arrray=new Vector[sizze];
    for(int i=0;i<sizze;i++)
        arrray[i]=vec.arrray[i];
    cout<<"se creo arreglo de vectores"<<endl;
}

void Vectorarray::resize(const int a){
    Vector* v;
    v=new Vector[a];
    this->sizze = a;
    for(int i=0;i<a;i++)
        v[i]=arrray[i];
    delete[] arrray;
    arrray = v;
}
void Vectorarray::finit(const Vector v){
    resize(sizze + 1);
    arrray[sizze-1]=v;
}
void Vectorarray::inserta(const Vector vv, const int x){
    resize(sizze + 1);
    for(int i = sizze; i > x;i--)
        arrray[i] = arrray[--i];
    arrray[x]=vv;
}
void Vectorarray::remover(const int pos){
    for(int i=pos+1;i<=sizze;i++)
        arrray[i-1]=arrray[i];
    resize(sizze-1);
}

int Vectorarray::getSize(){
    return sizze;
}
void Vectorarray::clean(){
    resize(0);
    delete[] arrray;
}
Vector* Vectorarray::getvector(const int position){
    for(int i=0;i<sizze;i++)
        if(i==position)
            return &arrray[i];
    return NULL;
}
void Vectorarray::imprimelo(){
    for(int i=0;i<sizze;i++)
        arrray[i].imprimir();
}
