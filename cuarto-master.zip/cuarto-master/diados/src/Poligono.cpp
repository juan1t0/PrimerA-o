#include "Poligono.h"
#include "pointarray.h"
#include "point.h"
#include <iostream>
#include <cmath>

using namespace std;


Poligono::Poligono(){
    Point o[0];
    Pointarray a(o,0) ;
    vertices = a;
    //ins+=1;
    cout <<"poligono creado"<<endl;
}
Poligono::Poligono(Point s[],int siz){
    Pointarray a(s,siz);
    vertices=a;
    //ins +=1;
    cout <<"poligono creado"<<endl;
}
Poligono::Poligono(Pointarray p){
    vertices = p;
    //ins +=1;
    cout<<"poligono creado"<<endl;
}
Poligono::Poligono(Poligono &h){
    vertices=h.vertices;
//    ins+= 1;
    cout<<"poligono creado"<<endl;
}
//const int Poligono::getnum(){return ins;}

const int Poligono::getsides(){
    return  vertices.getSize();
}
const Pointarray* Poligono::getvertices(){
    return &vertices ;
}
Poligono::~Poligono(){}

//------------------------------------------------------------

Rectangulo::Rectangulo(Point x,Point y){
    Point* a;
    a = new Point[4];
    a[0]=x;a[1]=Point(x.getX(),y.getY());
    a[2]=y;a[3]=Point(y.getX(),x.getY());
    Pointarray v(a,3);
    vertices = v;

    cout<<"rectangulo creado"<<endl;

}
Rectangulo::Rectangulo(int x1,int x2,int y1,int y2){
    Point* a;
    a = new Point[4];
    a[0]=Point(x1,y1);
    a[1]=Point(x1,y2);
    a[2]=Point(x2,y2);
    a[3]=Point(x2,y1);
    Pointarray v(a,3);
    vertices = v;
    cout<<"rectangulo creado"<<endl;

}
double Rectangulo::area(){
    double ar,b1,b2;
    Point* v1 = vertices.getpoint(2);
    Point* v2 = vertices.getpoint(0);
    b1=(v1->getX())-(v2->getX());
    b2=(v1->getY())-(v2->getY());
    ar=b1*b2;
    return ar;
}
//-------------

Triangulo::Triangulo(Point t1,Point t2,Point t3){
    Point* a;
    a = new Point[3];
    a[0]=t1;
    a[1]=t2;
    a[2]=t3;
    Pointarray v(a,3);
    vertices = v;
    cout<<"triangulo creado"<<endl;
}
double Triangulo::area(){
    double ar,a,b,c,semi;
    Point *p,*q,*r;
    p=vertices.getpoint(0);
    q=vertices.getpoint(1);
    r=vertices.getpoint(2);

    a= p->distancia(*q);
    b= q->distancia(*r);
    c= r->distancia(*p);

    semi = (a+b+c)/2;

    ar=sqrt(semi*(semi-a)*(semi-b)* (semi-c));
    return ar;

}
