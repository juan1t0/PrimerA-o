#include "point.h"
#include <iostream>
#include <cmath>

using namespace std;
Point::Point(){
    x=0.0;y=0.0;
}
Point::Point(double a,double b){
    x= a;y=b;
}
Point::Point(Point &p){
    x=p.getX();
    y=p.getY();
}
void Point::print(){
    cout<<"("<<x<<","<<y<<")"<<endl;
}
double Point::getX(){
    return x;
}
double Point::getY(){
    return y;
}
void Point::setX(double xx){
    x=xx;
}
void Point::setY(double yy){
    y=yy;
}

double Point::distancia(Point a){
    double r1,r2,r;
    r1 = pow(((a.getX())-(x)),(2));
    r2 = pow(((a.getY())-(y)),(2));
    r = sqrt(r1+r2);
    return r;
}
Point::~Point()
{

}
