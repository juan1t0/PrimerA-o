# juego

ultima modificacion         jueves 01 de diciembre del año 2016

H & R:
Querido jugador,
Antes que nada quiziera agradecerte por tu apoyo. Nosotros realmente
apreciamos que hayas decidido gastar tu dinero en nuestro juego y 
esperamos que tengas un grato y divertido tiempo juegandolo. Son casi
cinco meses trabajando en 'villano de guitarra' y nos es grato presen-
tarte nuestro juego.
Atentamente H&R, nosotros creemos que cuando tu compras un juego 
quieres continuar jugandolo por mucho tiempo, por eso existen las 
actualizaciones, parches, u contenido sorprendente. Estas cosas no 
podrian dejar de estar en nuestro juego, por eso nos es grato anunciarte 
que en los proximos meses podras descargar 16 DLCs complentamente 
gratis, los cuales podrian incluir canciones nuevas, nueva interfaz ,o
cualquier otra cosa que puedas imaginar.
Agradecemos tu apoyo y deseamos que disfrutes de la siguiente generacion
de juegos musicales.

H & R

//para mas informacion visita www.villanodeguitarra.com.qt/games despues de navidad

|-----------------------------------------------------------------|
|                                                                 |              
| VILLANO DE GUITARRA                                             |
|                                                                 |
| -Es un juego donde podras simular el tocar una guirarra. ¿crees |
| poder lograrlo?.                                                | 
| -Los controles son muy sencillos, solo preciona A-S-J-K-L en el |
| momento justo y gana(informacion detallada dentro del juego).   |
| -Alcanza los mejores puntajes en las diferentes dificultades y  |
| comparala con los mejores del mundo.                            |
| -En caso de algun problema visita                               |
| www.villanodeguitarra.com.qt/games/support .                    |
|-----------------------------------------------------------------|



Se recervan los derechos de autor.
En este juego se hace referencia y uso de 6 canciones conocidas mundialmente:
- 1 cancion de Slayer.
- 1 cancion de Led Zeppelin.
- 1 cancion de Tenacius D.
- 1 cacnion de Nigthwish.
- 1 cancion de Modest Mouse.
- 1 cover de Iron Maiden.

                                                                  H&R
