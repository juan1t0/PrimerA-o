#ifndef SCORE_H
#define SCORE_H

#include <QDialog>

namespace Ui {
class Score;
}

class Score : public QDialog
{
    Q_OBJECT

public:
    explicit Score(int score,QWidget *parent = 0);
    ~Score();

private slots:
    void on_pushButton_clicked();

    void on_salvar_clicked();

private:
    Ui::Score *ui;
    int sco;
};

#endif // SCORE_H
