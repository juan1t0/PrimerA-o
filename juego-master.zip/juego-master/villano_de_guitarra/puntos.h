#ifndef PUNTOS_H
#define PUNTOS_H

#include <QDialog>
#include <QString>
#include <QFile>
#include <QTextStream>

namespace Ui {
class Puntos;
}

class Puntos : public QDialog
{
    Q_OBJECT

public:
    explicit Puntos(QWidget *parent = 0);
    ~Puntos();

private slots:
    void on_actualizar_clicked();

private:
    Ui::Puntos *ui;
    QString nombre;

    QFile *fill;
    QTextStream * dil;
};

#endif // PUNTOS_H
