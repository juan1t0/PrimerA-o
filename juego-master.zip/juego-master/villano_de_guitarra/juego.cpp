#include "juego.h"
#include "ui_juego.h"
#include "nana.h"
#include "score.h"

#include <QWidget>
#include <QLabel>
#include <QLayout>
#include <QThread>
#include <QEvent>
#include <QKeyEvent>
#include <QElapsedTimer>

//-----------------------------------------------------------


//----------------------------------------------------------

Juego::Juego(QWidget *parent,int dificul,QString cancion,int duracion) :
    QDialog(parent),
    ui(new Ui::Juego)
{
    ui->setupUi(this);
    publico=new QMediaPlayer;
    publico->setMedia(QUrl::fromLocalFile("/home/juanpablo/ccomph/qt/guitar/musica/Publico.mp3"));

    vel=dificul ; song=cancion; dur = duracion;

    cronometro_1 = new QTimer(this);

    connect(cronometro_1,SIGNAL(timeout()),this,SLOT(mov()));

    publico->play();
}

Juego::~Juego()
{
    delete ui;
}

void Juego::on_empezar_clicked()
{
    cancion1 = new QMediaPlayer;
    publico->stop();
    QThread::sleep(2);

    QElapsedTimer tiempo;
    tiempo.start();
    cancion1->setMedia(QUrl::fromLocalFile(song));
    cancion1->play();

    cronometro_1->start(vel);

}

void Juego::mov(){
    pare +=1;
    if(pare >= ((dur * 1000)/vel)){
        cronometro_1->stop();
        cancion1->stop();
        on_pushButton_clicked();
    }

    a->mover(0,10);
    ui->nota1->addWidget(a);
    if(a->getY()>=270){
        a->refresh();
        score -= 2;
    }
    s->mover(0,7);
    ui->nota_2->addWidget(s);

    if(s->getY()>=270){
        s->refresh();
        score -= 2;
    }
    j->mover(0,8);
    ui->nota_3->addWidget(j);

    if(j->getY()>=270){
        j->refresh();
        score -= 2;
    }
    k->mover(0,6);
    ui->nota_4->addWidget(k);

    if(k->getY()>=270){
        k->refresh();
        score -= 2;
    }
    l->mover(0,11);
    ui->nota_5->addWidget(l);

    if(l->getY()>=270){
        l->refresh();
        score -= 2;
    }
    if(score<=0){
        cronometro_1->stop();
        cancion1->stop();
        on_pushButton_clicked();
    }
}

void Juego::keyPressEvent(QKeyEvent *a){

    if (a->key() == Qt::Key_A)
        on_A_clicked();
    if (a->key() == Qt::Key_S)
        on_S_clicked();
    if (a->key() == Qt::Key_J)
        on_J_clicked();
    if (a->key() == Qt::Key_K)
        on_K_clicked();
    if (a->key() == Qt::Key_L)
        on_L_clicked();

}

void Juego::on_A_clicked()
{
    if(a->getY()>= 225 && a->getY() <271 ){
        score +=2;
        cancion1->setVolume(100);
        a->refresh();
        a->mover(0,-100);
    }
    else{
        score -=2;
        cancion1->setVolume(30);}
}

void Juego::on_S_clicked()
{
    if(s->getY()>= 225 && s->getY() <271 ){
        score +=2;
        cancion1->setVolume(100);
        s->refresh();
        s->mover(0,-87);
    }
    else{
        cancion1->setVolume(30);
        score -=2;}
}

void Juego::on_J_clicked()
{
    if(j->getY()>= 225 && j->getY() <271 ){
        score +=2;
        cancion1->setVolume(100);
        j->refresh();
        j->mover(0,-93);
    }
    else{
        cancion1->setVolume(30);
        score -=2;}
}
void Juego::on_K_clicked()
{
    if(k->getY()>= 225 && k->getY() <271 ){
        score +=2;
        cancion1->setVolume(100);
        k->refresh();
        k->mover(0,-50);
    }
    else{
        cancion1->setVolume(30);
        score -=2;}
}
void Juego::on_L_clicked()
{
    if(l->getY()>= 225 && l->getY() <271 ){
        score +=2;
        cancion1->setVolume(100);
        l->refresh();
        l->mover(0,-103);
    }
    else{
        cancion1->setVolume(30);
        score -=2;}
}
void Juego::on_pushButton_clicked()
{
    Score* scor=new Score(score);
    scor->show();
    cancion1->stop();
    this->hide();
}
