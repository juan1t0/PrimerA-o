#ifndef INST_H
#define INST_H

#include <QDialog>

namespace Ui {
class Inst;
}

class Inst : public QDialog
{
    Q_OBJECT

public:
    explicit Inst(QWidget *parent = 0);
    ~Inst();

private slots:
    void on_volver_clicked();

private:
    Ui::Inst *ui;
};

#endif // INST_H
