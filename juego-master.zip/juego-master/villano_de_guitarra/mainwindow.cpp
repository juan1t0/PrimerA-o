#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dificul.h"
#include "puntos.h"
#include "inst.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    fondo = new QMediaPlayer;
    fondo->setMedia(QUrl::fromLocalFile("/home/juanpablo/ccomph/qt/guitar/musica/Black sabbath - wheels of confusion.mp3"));
    fondo->play();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    Dificul *esdificultad = new Dificul(this);
    fondo->stop();
    esdificultad->show();
    this->hide();
}

void MainWindow::on_actionVer_Puntuaciones_triggered()
{
    Puntos * ver= new Puntos;
    fondo->stop();
    ver->show();
    this->hide();

}

void MainWindow::on_instrucciones_clicked()
{
    Inst * tecla = new Inst;
    tecla->show();

}
