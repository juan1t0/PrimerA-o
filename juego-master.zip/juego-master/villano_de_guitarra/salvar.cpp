#include "salvar.h"
#include "ui_salvar.h"
#include "mainwindow.h"
#include <QString>
#include "puntos.h"
#include <QFile>
#include <QTextStream>


Salvar::Salvar(QWidget *parent,int scor) :
    QDialog(parent),
    ui(new Ui::Salvar)
{
    scorr = scor;
    ui->setupUi(this);
    file = new QFile("/home/juanpablo/ccomph/villanos_de_guitarra/villano_de_guitarra/ptos/puntos.txt");
//   file->open(QIODevice::WriteOnly |QIODevice::Truncate);
    del = new QTextStream(file);
//    dol = new QTextStream(file);
}

Salvar::~Salvar()
{
    delete ui;
}

void Salvar::on_guardar_clicked()
{
    QString sc = QString::number(scorr);

    file->open(QIODevice::ReadOnly);
    QString res = del->readAll();
    file->close();

    QString name = (ui->nick->text()) +"  ->  " +sc + '\n';
    QString tot = res + name;

    file->open(QIODevice::WriteOnly |QIODevice::Truncate);
    *del << tot;
    file->close();

    Puntos *otra = new Puntos(this);
    otra->show();
    this->hide();
}
