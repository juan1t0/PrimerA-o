#include "inst.h"
#include "ui_inst.h"

Inst::Inst(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Inst)
{
    ui->setupUi(this);
}

Inst::~Inst()
{
    delete ui;
}

void Inst::on_volver_clicked()
{
    this->hide();
}
