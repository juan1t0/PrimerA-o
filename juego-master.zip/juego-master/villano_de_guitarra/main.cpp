#include "mainwindow.h"
#include <QApplication>
#include <QMediaPlayer>
#include "data.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    //data::obj();

    w.show();

    return a.exec();
}
