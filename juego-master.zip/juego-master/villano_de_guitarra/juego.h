#ifndef JUEGO_H
#define JUEGO_H

#include <QString>
#include <QDialog>
#include <QLabel>
#include <QMediaPlayer>
#include <QTimer>
#include <QEvent>
#include <QKeyEvent>
#include <QVector>

#include "nana.h"

namespace Ui {
class Juego;
}

class Juego : public QDialog
{
    Q_OBJECT

public:
    explicit Juego(QWidget *parent = 0,int dificul=0,QString cancion="nana",int duracion=0);
    ~Juego();

private slots:
    void on_empezar_clicked();
    void mov();


    void on_A_clicked();
    void on_S_clicked();
    void on_J_clicked();
    void on_K_clicked();
    void on_L_clicked();

    void on_pushButton_clicked();

private:
    Ui::Juego *ui;
    QMediaPlayer* publico;
    int score = 100;
    QMediaPlayer *cancion1;

    QTimer *cronometro_1;

  //  QVector<*nana> notas;
    nota1 *a = new nota1(this);
    nota2 *s = new nota2(this);
    nota3 *j = new nota3(this);
    nota4 *k = new nota4(this);
    nota5 *l = new nota5(this);

    QKeyEvent *event;

    int vel;
    QString song;
    int pare=0; int dur;

    void keyPressEvent(QKeyEvent *a);
};

#endif // JUEGO_H
