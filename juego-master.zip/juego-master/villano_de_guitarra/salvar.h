#ifndef SALVAR_H
#define SALVAR_H

#include <QDialog>
#include <QFile>
#include <QTextStream>

namespace Ui {
class Salvar;
}

class Salvar : public QDialog
{
    Q_OBJECT

public:
    explicit Salvar(QWidget *parent = 0,int scor=0);
    ~Salvar();

private slots:
    void on_guardar_clicked();

private:
    Ui::Salvar *ui;
    int scorr;
    QFile *file;
    QTextStream *del;
    QTextStream *dol;
};

#endif // SALVAR_H
