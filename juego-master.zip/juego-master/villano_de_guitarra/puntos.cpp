#include "puntos.h"
#include "ui_puntos.h"
#include <QLabel>
#include <QString>
#include <QFile>
#include <QTextStream>

Puntos::Puntos(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Puntos)
{
    ui->setupUi(this);
    fill = new QFile("/home/juanpablo/ccomph/villanos_de_guitarra/villano_de_guitarra/ptos/puntos.txt");
    fill->open(QIODevice::ReadOnly);
    dil = new QTextStream(fill);
    nombre = dil->readAll();

    QLabel *pets = new QLabel;

    pets->setText(nombre);
    //pets->;
    ui->lay->addWidget(pets);
}

void Puntos::on_actualizar_clicked()
{

}

Puntos::~Puntos()
{
    delete ui;
}
