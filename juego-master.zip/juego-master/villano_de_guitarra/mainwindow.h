#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMediaPlayer>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);

    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_actionVer_Puntuaciones_triggered();

    void on_instrucciones_clicked();

private:
    Ui::MainWindow *ui;
    QMediaPlayer *fondo;
};

#endif // MAINWINDOW_H
