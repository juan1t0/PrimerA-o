#include "dificul.h"
#include "ui_dificul.h"
#include "canciones.h"
#include <QMediaPlayer>

Dificul::Dificul(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dificul)
{
    ui->setupUi(this);
    fondo = new QMediaPlayer;
    fondo->setMedia(QUrl::fromLocalFile("/home/juanpablo/ccomph/qt/guitar/musica/Fenix1.mp3"));
    fondo->setVolume(50);
    fondo->play();
}

Dificul::~Dificul()
{
    delete ui;
}

void Dificul::on_principiante_clicked()
{
    Canciones *escancion = new Canciones(this,50);
    fondo->stop();
    escancion->show();
    this->hide();
}

void Dificul::on_aficionado_clicked()
{
    Canciones *escancion = new Canciones(this,40);

    fondo->stop();
    escancion->show();
    this->hide();
}

void Dificul::on_semipro_clicked()
{
    Canciones *escancion = new Canciones(this,30);
    fondo->stop();
    escancion->show();
    this->hide();
}

void Dificul::on_profecional_clicked()
{
    Canciones *escancion = new Canciones(this,25);
    fondo->stop();
    escancion->show();
    this->hide();
}
