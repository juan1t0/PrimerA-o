#include "nota.h"
#include <QWidget>
#include <QPainter>


Nota::Nota(QWidget *parent) : QWidget(parent)
{
}

void Nota::dibujar(QPaintEvent *)
{
    QPainter nnta(this);
    nnta.setBrush(Qt::magenta);
    nnta.drawEllipse(0,0, 20,20);
}
