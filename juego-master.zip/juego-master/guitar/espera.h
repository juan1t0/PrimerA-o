#ifndef ESPERA_H
#define ESPERA_H

#include <QDialog>

namespace Ui {
class Espera;
}

class Espera : public QDialog
{
    Q_OBJECT

public:
    explicit Espera(QWidget *parent = 0);
    ~Espera();

private:
    Ui::Espera *ui;
};

#endif // ESPERA_H
