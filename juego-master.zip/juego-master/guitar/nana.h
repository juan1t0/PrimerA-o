#ifndef NANA_H
#define NANA_H

#include <QWidget>
#include <QPainter>

class nana : public QWidget
{
    Q_OBJECT
public:
    explicit nana(QWidget *parent = 0);
    void mover(int x,int y);
    void refresh();
    int getX();
    int getY();
    int getMargen();

signals:

public slots:

protected:
//    virtual void paintEvent();

public:
    int x,y;
    int margen = 0;

};

class nota1: public nana
{
public:
    explicit nota1(QWidget *parent = 0);
protected:
    void paintEvent(QPaintEvent *event);
};

class nota2: public nana
{
public:
    explicit nota2(QWidget *parent = 0);
protected:
    void paintEvent(QPaintEvent *event);
};

class nota3: public nana
{
public:
    explicit nota3(QWidget *parent = 0);
protected:
    void paintEvent(QPaintEvent *event);
};

class nota4: public nana
{
public:
    explicit nota4(QWidget *parent = 0);
protected:
    void paintEvent(QPaintEvent *event);
};

class nota5: public nana
{
public:
    explicit nota5(QWidget *parent = 0);
protected:
    void paintEvent(QPaintEvent *event);
};


#endif // NANA_H
