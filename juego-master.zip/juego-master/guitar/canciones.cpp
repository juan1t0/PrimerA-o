#include "canciones.h"
#include "ui_canciones.h"
#include "juego.h"
#include <QMediaPlayer>

Canciones::Canciones(QWidget *parent,int dificulss) :
    QDialog(parent),
    ui(new Ui::Canciones)
{
    ui->setupUi(this);
    fondo = new QMediaPlayer;
    fondo->setMedia(QUrl::fromLocalFile("/home/juanpablo/ccomph/qt/guitar/musica/Fenix1.mp3"));
    fondo->play();
    vel=dificulss;
}

Canciones::~Canciones()
{
    delete ui;
}

void Canciones::on_cancion1_clicked()
{
    Juego *panjuego = new Juego(this,vel,"/home/juanpablo/ccomph/villanos_de_guitarra/villano_de_guitarra/musica/UFO-doctor doctor.mp3");
    fondo->stop();
    panjuego->show();
    this->hide();
}

void Canciones::on_cancion3_clicked()
{
    Juego *panjuego = new Juego(this,vel,"/home/juanpablo/ccomph/villanos_de_guitarra/villano_de_guitarra/musica/Modest mouse - the ground walks.mp3");
    fondo->stop();
    panjuego->show();
    this->hide();
}

void Canciones::on_cancion2_clicked()
{
    Juego *panjuego = new Juego(this,vel,"/home/juanpablo/ccomph/villanos_de_guitarra/villano_de_guitarra/musica/nightwish - amarath.mp3");
    fondo->stop();
    panjuego->show();
    this->hide();
}

void Canciones::on_cancion4_clicked()
{
    Juego *panjuego = new Juego(this,vel,"/home/juanpablo/ccomph/villanos_de_guitarra/villano_de_guitarra/musica/Slayer - seasons in the abyss.mp3");
    fondo->stop();
    panjuego->show();
    this->hide();
}
