#include "espera.h"
#include "ui_espera.h"

Espera::Espera(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Espera)
{
    ui->setupUi(this);
}

Espera::~Espera()
{
    delete ui;
}
