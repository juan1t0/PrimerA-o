#ifndef CANCIONES_H
#define CANCIONES_H

#include <QDialog>
#include <QMediaPlayer>


namespace Ui {
class Canciones;
}

class Canciones : public QDialog
{
    Q_OBJECT

public:
    explicit Canciones(QWidget *parent = 0,int dificulss=0);
    ~Canciones();

private slots:
    void on_cancion1_clicked();

    void on_cancion3_clicked();

    void on_cancion2_clicked();

    void on_cancion4_clicked();

private:
    Ui::Canciones *ui;
    QMediaPlayer *fondo;
    int vel;
};

#endif // CANCIONES_H
