#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dificul.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    fondo = new QMediaPlayer;
    fondo->setMedia(QUrl::fromLocalFile("/home/juanpablo/ccomph/qt/guitar/musica/Black sabbath - wheels of confusion.mp3"));
    fondo->play();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    Dificul *esdificultad = new Dificul(this);
    fondo->stop();
    esdificultad->show();
    this->hide();
}
