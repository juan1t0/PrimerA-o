#include "nana.h"
#include <QPainter>
#include <QThread>

nana::nana(QWidget *parent) : QWidget(parent)
{
    x=0;y=0;
}


void nana::mover(int x,int y){
    this->x += x;
    this->y += y;
    margen +=1;
    update();
}
void nana::refresh(){
    x=0;
    y=0;
    margen = 0;
}
int nana::getX(){
    return x;
}

int nana::getY(){
    return y;
}
int nana::getMargen(){
    return margen;
}

nota1::nota1(QWidget *parent){
    x=0;y=0;
}

void nota1::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setBrush(Qt::magenta);

    painter.drawEllipse(x,y,30,20);

}


nota2::nota2(QWidget *parent){
    x=0;y=0;
}
void nota2::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setBrush(Qt::green);

    painter.drawEllipse(x,y,30,20);

}

nota3::nota3(QWidget *parent){
    x=0;y=0;
}
void nota3::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setBrush(Qt::blue);

    painter.drawEllipse(x,y,30,20);

}

nota4::nota4(QWidget *parent){
    x=0;y=0;
}
void nota4::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setBrush(Qt::red);

    painter.drawEllipse(x,y,30,20);

}

nota5::nota5(QWidget *parent){
    x=0;y=0;
}
void nota5::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setBrush(Qt::white);

    painter.drawEllipse(x,y,30,20);

}
