#ifndef NOTA_H
#define NOTA_H
#include <QWidget>


class Nota
{
    Q_OBJECT
public:
    Nota(QWidget *parent=0);
protected:
    void dibujar(QPaintEvent *);

};

#endif // NOTA_H
