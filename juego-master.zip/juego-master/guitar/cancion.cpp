/*#include "cancion.h"
#include <QMediaPlayer>
#include "nana.h"

Cancion::Cancion(QWidget *parent) : QWidget(parent)
{

}
Cancion1::Cancion1(QWidget *parent, QString file){
    cancion = new QMediaPlayer;
    cancion->setMedia(QUrl::fromLocalFile(file));
}

nana Cancion1::notas(dificultad, dificul){
    nana* nota=new nana;
    nota->setDificultad(dificul);
    nota->setVelocidad(dificultad);
    return *nota;
}
*/
