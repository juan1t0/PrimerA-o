#include "score.h"
#include "ui_score.h"
#include "mainwindow.h"
#include <QString>


Score::Score(int score,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Score)
{
    ui->setupUi(this);
    sco =score;
    QString s = QString::number(sco);
    ui->label->setText(s);
}

Score::~Score()
{
    delete ui;
}

void Score::on_pushButton_clicked()
{
    MainWindow* otra = new MainWindow();
    otra->show();
    this->hide();
}
