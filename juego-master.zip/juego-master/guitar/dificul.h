#ifndef DIFICUL_H
#define DIFICUL_H

#include <QDialog>
#include <QMediaPlayer>


namespace Ui {
class Dificul;
}

class Dificul : public QDialog
{
    Q_OBJECT

public:
    explicit Dificul(QWidget *parent = 0);

    ~Dificul();

private slots:
    void on_principiante_clicked();

    void on_aficionado_clicked();

    void on_semipro_clicked();

    void on_profecional_clicked();

private:
    Ui::Dificul *ui;
    QMediaPlayer *fondo;

};

#endif // DIFICUL_H
