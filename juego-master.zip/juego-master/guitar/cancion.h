/*#ifndef CANCION_H
#define CANCION_H

#include <iostream>
#include <QWidget>
#include <QMediaPlayer>
#include <QString>
#include <QVector>


#include "nana.h"
class Cancion : public QWidget
{
    Q_OBJECT
public:
    explicit Cancion(QWidget *parent = 0);

    virtual nana notas(dificultad,dificul) = 0;
    virtual int score()=0;

signals:

public slots:

protected:

private:
    QMediaPlayer *cancion;
    double dificultad;
    QString *dificul;
    QVector<*nana> notas;
};

#endif // CANCION_H


class Cancion1 : public Cancion
{
public:
    Cancion1(QWidget* parent=0,QString);
    nana notas(dificultad, dificul);

    int score();
};

class Cancion2 : public Cancion
{
public:
    Cancion2(QWidget* parent=0,QString);
    nana notas(dificultad, dificul);

    int score();
};

class Cancion3 : public Cancion
{
public:
    Cancion3(QWidget* parent=0,QString);
    nana notas(dificultad, dificul);

    int score();
};

class Cancion4 : public Cancion
{
public:
    Cancion4(QWidget* parent=0,QString);
    nana notas(dificultad, dificul);

    int score();
};
*/
