#include <stdio.h>
#include <stdlib.h>

struct nodo{
	int valor;
	struct nodo *next;
};


void imprimir(struct nodo *a);
struct nodo inserta_inicio(struct nodo *head,int val);
void crealist(struct nodo *head, int n);
void inserta_medio(struct nodo *head,int val,int i);
void inserta_orden(struct nodo *head,int val);
void concatena(struct nodo * t, struct nodo *s);

main()
{
	struct nodo *head,*inicio,*primo;
	head = malloc(sizeof(struct nodo));
	inicio=malloc(sizeof(struct nodo));
    head->valor=0;
	crealist(head,7);
	imprimir(head);
	*inicio = inserta_inicio(head,1);
	imprimir(inicio);
	head = inicio;
	inserta_medio(head,0,2);
	inserta_orden(head,6);

    primo=malloc(sizeof(struct nodo));
    crealist(primo,5);
    primo->valor=0;
    imprimir(primo);
    concatena(head,primo);
    imprimir(head);
	return 0;
}

void imprimir (struct nodo *a)
{
    int i;
    for(i=0;a != NULL;i++){
        printf("| %d ", a->valor);
        a = a -> next;
    }
    printf("|\n tiene %d elementos\n",i);

}

void crealist(struct nodo *head, int n)
{
	int i;
	struct nodo *prev,*cur;
	prev=malloc(sizeof(struct nodo));
	prev = head;

	for(i=1;i<=n;i++){
		cur=malloc(sizeof(struct nodo));
		cur->valor=i;
		prev->next=cur;
		prev=cur;
	}
	prev ->next=NULL;
}
struct nodo inserta_inicio(struct nodo *head, int val)
{
	struct nodo *temp;
	temp = malloc(sizeof(struct nodo));

	temp->valor=val;
	temp->next=head;
	return *temp;
}
void inserta_medio(struct nodo *head,int val,int i)
{
	struct nodo *temp,*act,*prev;
	temp = malloc(sizeof(struct nodo));
	act = malloc(sizeof(struct nodo));
	prev = malloc(sizeof(struct nodo));

	temp->valor= val;
	temp->next = NULL;

	int a =0;
	prev = head;
	for(; a<i ;a++){
		act=head;
		head = head->next;

	}
    act->next=temp;
    temp->next=head;

    imprimir(prev);
}

void inserta_orden(struct nodo *head,int val)
{
	int i;
	struct nodo *aux;
	aux=malloc(sizeof(struct nodo));
	aux=head;
	for(i=0;aux->next != NULL && aux->valor <= val;i++)
		aux=aux->next;

	inserta_medio(head,val,i);
}

void concatena(struct nodo * t, struct nodo *s)
{
	while(t->next!= NULL)
		t = t->next;

	t->next = s;

}


